package com.example.gerenciadorcompromissos

class Compromisso (var titulo: String, var data: String, var horaInicio: String,
                   var horaFim: String, var descricao: String)